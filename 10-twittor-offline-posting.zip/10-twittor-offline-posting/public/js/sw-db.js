

const db = new PouchDB('mensajes');


//Utlidades para gurdar en el Pouch DB

function guardarMensaje(mensaje){

    mensaje._id = new Date().toISOString();

    return db.put(mensaje).then( () => {

            self.registration.sync.register('nuevo-post');

            const newResponse = { ok: true, offline: true};

            return new Response(JSON.stringify(newResponse))
        // console.log('Mensaje Guardado en DB')
    })

}

//Postear MEnsajes 


function postearMensajes(){

db.allDocs({include_docs:true}).then(docs => {


    const posteos = [];

   return docs.rows.forEach(row  => {
        const doc = row.doc;

       const fetchPom = fetch('api', {
            method: 'POST',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify(doc)
        
        }).then(res =>{

          return  db.remove(doc);

        });


        posteos.push(fetchPom);

    }); //FIn For each

    return Promise.all(posteos);

})

}
