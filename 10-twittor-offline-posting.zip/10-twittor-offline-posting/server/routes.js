// Routes.js - Módulo de rutas
const express = require('express');
const router = express.Router();
const push = require('./push');


const mensajes =[
  {
    _id: 'ttt',
    user: 'spiderman',
    mensaje: 'Hola mundo'
  }
]




// Post mensajes
router.post('/', function (req, res) {
 // res.json('Obteniendo mensajes');
const mensaje ={
  mensaje: req.body.mensaje,
  user: req.body.user
}

mensajes.push(mensaje)

console.log(mensajes)


res.json({
  ok: true,
  mensaje
} );

});


// Get mensajes
router.get('/', function (req, res) {
 // res.json('Obteniendo mensajes');

 res.json(mensajes)
});

//ALmacenar la subscripcion
router.post('/subscribe', (req,res)=>{
  // console.log(req)

  const suscripcion = req.body;
//  console.log(suscripcion)  ;

push.addSubscription(suscripcion)
  
  
  res.json('subscribe')
})

//ALmacenar la subscripcion
router.get('/key', (req,res)=>{
  // res.json('key publico')


const key = push.getKey();


// res.json(key);
res.send(key);


})

//Enviar notificacion push a las personas que queramos 
//Es algo que se controla del lado del server
router.post('/push', (req,res)=>{

  const post = {
    titulo: req.body.titulo,
    cuerpo: req.body.cuerpo,
    usuario: req.body.usuario
  }

  push.sendPush(post);
//console.log(notificacion)
  res.json(post)
})




module.exports = router;